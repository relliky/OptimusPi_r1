/*
 * debug.h
 *
 *  Created on: 10 Feb 2015
 *      Author: Tai
 */


#ifndef DEBUGOPTIONS_H_
#define DEBUGOPTIONS_H_

	#define DEBUG
//	#define DEBUG_PRINTF_VIA_JTAG

	/* Enable all tests */
	//#define DEBUG_RUN_ALL_TEST

	/* Enable each individual test */
	#define DEBUG_RUN_I2C_BASIC_TEST

	#define DEBUG_RUN_CONT_MPU_TEST

//	#define DEBUG_RUN_PRINTF_TEST



#endif /*DEBUGOPTIONS_H_ */
