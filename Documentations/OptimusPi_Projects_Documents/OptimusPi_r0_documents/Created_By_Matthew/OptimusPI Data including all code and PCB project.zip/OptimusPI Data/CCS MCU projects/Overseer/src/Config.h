/*
 * Config.h
 *
 *  Created on: 8 Sep 2014
 *      Author: admin
 */

#ifndef CONFIG_H_
#define CONFIG_H_

#define MCU_OVERSEER



#endif /* CONFIG_H_ */
