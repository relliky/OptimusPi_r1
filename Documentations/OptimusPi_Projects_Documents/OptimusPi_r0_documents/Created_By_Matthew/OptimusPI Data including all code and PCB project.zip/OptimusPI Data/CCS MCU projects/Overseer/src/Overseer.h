/*
 * main.h
 *
 *  Created on: 18 Jul 2014
 *      Author: admin
 */

#ifndef OVERSEER_H_
#define OVERSEER_H_


#include <stdbool.h>
#include <stdint.h>
#include "driverlib/sysctl.h"

#include "shared/SPISlave.h"
#include "shared/SPICommands.h"
#include "MotorController.h"
#include "PinController.h"


void updateReadBuffers();
void emptyMessageQueue();



#endif /* OVERSEER_H_ */
