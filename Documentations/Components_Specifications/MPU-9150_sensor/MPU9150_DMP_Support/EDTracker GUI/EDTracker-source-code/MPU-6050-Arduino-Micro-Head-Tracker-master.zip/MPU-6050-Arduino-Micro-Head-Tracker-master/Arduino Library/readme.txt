Tested to work with Arduino IDE 1.5.6 and 1.0.5  (use appropriate version of USBAPI.h)


HID.cpp and USBAPI.h  replace the ones found under your Arduino IDE folder

<Arduino IDE>\hardware\arduino\avr\cores\arduino


Be sure to back up the existing files and then replace with these, renaming USBAPI.h.156 or USBAPI.h.105 to USBAPI.h as appropriate.