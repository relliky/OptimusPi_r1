============================================================================
Note: for more details about this project, please visit: 
http://reprapdad.wordpress.com/    

And watch the excellent video overview put together by Dan (aka Brumster)
https://www.youtube.com/watch?v=_oqLwCtMCKc&list=UUhhdxi3tHTrmpB4y4m3i0GA

============================================================================

A low cost Head Tracker For Elite Dangerous (or any other application).

Based on a Sparkfun Pro Micro/Arduino Micro or other ATMEGA32U4 clone plus an 
MPU-6050 6-axis accelerometer/gyroscope (InvenSense)

Requires the i2cdevlib from Jeff Rowberg https://github.com/jrowberg, 
specifically the Arduino MPU6050 and the I2CDev library.
