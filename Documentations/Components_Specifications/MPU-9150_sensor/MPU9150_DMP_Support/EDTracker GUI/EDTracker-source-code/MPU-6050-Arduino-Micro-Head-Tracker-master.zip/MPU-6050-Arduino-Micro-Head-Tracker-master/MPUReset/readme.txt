unzip the libraries folder so the contents appear under 

<arduino ide folder>/libraries.


Load the sketch.

Open serial monitor window (shift-ctrl-m)

